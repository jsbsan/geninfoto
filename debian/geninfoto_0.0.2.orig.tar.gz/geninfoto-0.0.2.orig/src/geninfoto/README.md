# geninfoto
